 var app = getApp()

 //获取登录态状态函数
// function isSKexpired(){
//   return new Promise(function(resolve,reject){
//     wx.checkSession({
//       success: () => {
//         resolve(true)
//       },
//       fail(){
//         reject(false)
//       }
//     })
//   })
// }

// module.exports.isSKexpired = isSKexpired